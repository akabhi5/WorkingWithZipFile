import shutil
''' with this module we can only work with folders '''

# make_archive('NewZipName', 'Format', 'TargetFile')
shutil.make_archive('another', 'zip', 'files')